This repo containers base code for LIC Dev Environment.
The code belong to Terraform for Infra as a Code(IaaC).